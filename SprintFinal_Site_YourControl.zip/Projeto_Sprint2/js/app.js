document.getElementById('login').addEventListener(
    'click', login, false
);


function login(evt) {
    //receber os dados que o usuario digitou no cadastro
    evt.preventDefault();
    var nome = document.getElementById('nome').value;
    var senha = document.getElementById('senha').value;

    var contatosStorage = JSON.parse(localStorage.getItem('contatos'));

    if (!contatosStorage) {
        alert("Você não esta cadastrado");
        return;
    }

    var permissao = false;

    for (let i = 0; i < contatosStorage.length; i++) {
        if (contatosStorage[i].nome == nome && contatosStorage[i].senha == senha) {
            permissao = true;
        }
    }

    if (permissao == false) {
        alert('Você não está cadastrado');
    }
    else {
      window.location = '../index1.html';  
      
    }
}

function saveAccount() {
    var contatos = [];

    var nome = document.getElementById('name').value;
    var sobrenome = document.getElementById('lastName').value;
    var email = document.getElementById('email').value;
    var senha = document.getElementById('password').value;
    var confirmarPassword = document.getElementById('confirmPassword').value;

    var contato = {
        nome: nome,
        sobrenome: sobrenome,
        email: email,
        senha: senha
    };

    if (validate(nome, sobrenome, email, senha, confirmarPassword)) {
        contatosStorage = JSON.parse(localStorage.getItem('contatos'));
        if (contatosStorage) {
            var exist = checkIfExistInStorage(contato, contatosStorage);
            if (exist) {
                alert("Já existe um contato com estes parametros. Faça login")
            } else {
                contatos = contatosStorage;
                contatos.push(contato);
                localStorage.setItem('contatos', JSON.stringify(contatos));
            }
        } else {
            contatos.push(contato);
            localStorage.setItem('contatos', JSON.stringify(contatos));
        }
    }
}

function validate(nome, sobrenome, email, senha, confirmarSenha) {
    return nome != '' && sobrenome != '' && email != '' && senha != '' && confirmarSenha != '' && senha == confirmarSenha;
}

function checkIfExistInStorage(contato, contatosStorage) {
    var existContact = false;

    for (let i = 0; i < contatosStorage.length; i++) {
        if (contatosStorage[i].nome == contato.nome && contatosStorage[i].senha == contato.senha) {
            existContact = true;
        }
    }

    return existContact;
}

function loadData() {
    var contatosStorage = JSON.parse(localStorage.getItem('contatos'));
    var element = document.getElementById('list');
    var html = '';

    if (contatosStorage) {

        for (let index = 0; index < contatosStorage.length; index++) {
            contato = contatosStorage[index];
            html += '<tr><td>' + contato.nome + '</td><td>' + contato.sobrenome + '</td><td>' + contato.email + '</td><td class="text-center"><a class="btn btn-info btn-xs" href="#"><span class="glyphicon glyphicon-edit"></span>Editar</a> <a href="#" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span>Excluir</a></td></tr>'
        }
        element.insertAdjacentHTML('beforeend', html);
    }
}



